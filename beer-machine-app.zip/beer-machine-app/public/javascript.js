
    document.getElementById("resetBtn").onclick=function (){
    document.getElementById("startBtn").onclick=function (){
        var bar = document.getElementById("myBar");
        var height = 100;
        bar.style.height = height+'%';
    }
};


